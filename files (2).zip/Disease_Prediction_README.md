# Disease Prediction from Medical Data

Machine-learning pipeline that predicts the **possibility of disease** from structured patient data,
using classification techniques on three UCI benchmark datasets.

| Dataset | Task | Samples | Features |
|---|---|---|---|
| Heart Disease (Cleveland) | coronary heart disease present? | 302 | 13 clinical (age, chest-pain type, cholesterol, ECG, ...) |
| Diabetes (Pima Indians) | diabetes onset? | 768 | 8 diagnostic (glucose, BMI, insulin, age, ...) |
| Breast Cancer (Wisconsin Diagnostic) | tumour malignant? | 569 | 30 cell-nucleus measurements |

**Algorithms:** Logistic Regression, SVM (RBF), Random Forest, XGBoost, each tuned with grid search.

> **Disclaimer:** research / educational project. Not a medical device and not a substitute for professional diagnosis.

## Quick start

```bash
pip install -e ".[dev]"                 # or: pip install -r requirements.txt
make train                              # python -m disease_prediction.train --dataset all
make test                               # 18 unit tests
python -m disease_prediction.predict --dataset heart --input examples/heart_patient.json
```

Train a single dataset: `python -m disease_prediction.train --dataset diabetes`
(`heart` | `diabetes` | `breast_cancer` | `all`). Training takes about 2 minutes on a laptop CPU.

Prefer a browser? Upload `notebooks/Disease_Prediction_Colab.ipynb` to [Google Colab](https://colab.research.google.com) and run all cells.

## Project structure

```
disease-prediction/
├── src/disease_prediction/
│   ├── config.py          paths, seed, CV / split settings
│   ├── data.py            dataset loaders (unified target: 1 = disease)
│   ├── preprocessing.py   imputation + scaling + one-hot (ColumnTransformer)
│   ├── models.py          SVM / LR / RF / XGBoost + tuning grids
│   ├── evaluate.py        metrics, bootstrap CI, ROC / confusion / importance plots
│   ├── train.py           tune -> select -> evaluate -> save (CLI)
│   └── predict.py         score new patients from JSON (CLI)
├── tests/                 pytest suite (data contracts, every model x dataset, metrics)
├── data/raw/              cached CSVs (auto re-downloaded if missing)
├── models/                saved best pipelines (.joblib)
├── reports/               metrics CSVs, results_summary.md, figures/
├── examples/              sample patient JSON files
└── notebooks/             Google Colab notebook
```

## Methodology

1. **Stratified 80/20 split** (seed 42) preserves class balance.
2. **Leakage-safe preprocessing.** Imputation, scaling and encoding live *inside* the sklearn `Pipeline`, so they are fit only on training folds.
3. **Data quality handling.**
   - Pima: zeros in glucose, blood pressure, skin thickness, insulin and BMI are physiologically impossible and treated as missing, then median-imputed.
   - Heart: nominal features (`cp`, `restecg`, `slope`, `thal`) are one-hot encoded; one duplicate row is removed.
   - **Target polarity is verified.** The public Cleveland copy used here codes `1` as *healthy*, and scikit-learn codes breast-cancer *malignant* as `0`. Both are flipped so that **1 always means disease**, and unit tests assert it.
4. **Class imbalance** handled with `class_weight="balanced"` (LR, SVM, RF) and `scale_pos_weight` (XGBoost).
5. **Tuning and model selection use 5-fold stratified CV on the training split only**, optimising ROC-AUC. The test set is never used to choose a model.
6. **Reported metrics:** Accuracy, Precision, Recall/Sensitivity, Specificity, F1, ROC-AUC (with bootstrap 95% CI), PR-AUC, plus confusion matrices and permutation feature importance.

## Results


Hold-out test metrics (20% stratified split, threshold 0.5). `CV ROC-AUC` is the 5-fold score on the training split used for model selection (**bold** = selected).


### Heart Disease (Cleveland)

| Model | CV ROC-AUC | Accuracy | Precision | Recall (Sensitivity) | Specificity | F1-Score | ROC-AUC | ROC-AUC 95% CI |
|---|---|---|---|---|---|---|---|---|
| Logistic Regression | 0.914 | 0.787 | 0.742 | 0.821 | 0.758 | 0.780 | 0.890 | [0.807, 0.961] |
| SVM | 0.913 | 0.787 | 0.778 | 0.750 | 0.818 | 0.764 | 0.881 | [0.797, 0.955] |
| **Random Forest** | **0.917** | **0.787** | **0.800** | **0.714** | **0.848** | **0.755** | **0.882** | **[0.796, 0.953]** |
| XGBoost | 0.907 | 0.787 | 0.800 | 0.714 | 0.848 | 0.755 | 0.905 | [0.830, 0.965] |

### Diabetes (Pima Indians)

| Model | CV ROC-AUC | Accuracy | Precision | Recall (Sensitivity) | Specificity | F1-Score | ROC-AUC | ROC-AUC 95% CI |
|---|---|---|---|---|---|---|---|---|
| Logistic Regression | 0.845 | 0.708 | 0.571 | 0.667 | 0.730 | 0.615 | 0.810 | [0.739, 0.872] |
| **SVM** | **0.849** | **0.708** | **0.600** | **0.500** | **0.820** | **0.545** | **0.810** | **[0.739, 0.872]** |
| Random Forest | 0.842 | 0.747 | 0.615 | 0.741 | 0.750 | 0.672 | 0.821 | [0.751, 0.884] |
| XGBoost | 0.839 | 0.753 | 0.618 | 0.778 | 0.740 | 0.689 | 0.812 | [0.738, 0.877] |

### Breast Cancer (Wisconsin Diagnostic)

| Model | CV ROC-AUC | Accuracy | Precision | Recall (Sensitivity) | Specificity | F1-Score | ROC-AUC | ROC-AUC 95% CI |
|---|---|---|---|---|---|---|---|---|
| Logistic Regression | 0.995 | 0.974 | 0.976 | 0.952 | 0.986 | 0.964 | 0.995 | [0.986, 1.000] |
| **SVM** | **0.996** | **0.991** | **1.000** | **0.976** | **1.000** | **0.988** | **0.996** | **[0.986, 1.000]** |
| Random Forest | 0.989 | 0.974 | 1.000 | 0.929 | 1.000 | 0.963 | 0.996 | [0.988, 1.000] |
| XGBoost | 0.995 | 0.974 | 1.000 | 0.929 | 1.000 | 0.963 | 0.992 | [0.972, 1.000] |

Figures (ROC curves, confusion matrices, feature importance) are written to `reports/figures/`.

| | |
|---|---|
| ![](reports/figures/heart_roc.png) | ![](reports/figures/diabetes_roc.png) |
| ![](reports/figures/breast_cancer_roc.png) | ![](reports/figures/heart_feature_importance.png) |

### Interpretation and caveats

- **Breast cancer** is nearly separable (AUC about 0.99); all four models perform similarly.
- **Heart disease and diabetes** are harder. Test sets are small (61 and 154 patients), so the bootstrap confidence intervals are wide and differences between models are mostly **within noise**.
- Heart disease: the strongest predictors are number of blocked vessels (`ca`), chest-pain type, thalassemia result and ST depression, consistent with clinical knowledge.
- **Threshold matters in medicine.** Metrics use the default 0.5 cut-off. For screening you would usually lower it to favour recall (missing a sick patient is costlier than a false alarm). The Pima SVM, for example, has recall of only 0.50 at 0.5.

## Possible extensions

Decision-threshold optimisation for target sensitivity, probability calibration, SHAP explanations,
nested CV for tighter estimates, external validation on a different cohort, and a Streamlit front end.

## Data sources

UCI Machine Learning Repository: Heart Disease (Cleveland), Pima Indians Diabetes (NIDDK), Breast Cancer Wisconsin (Diagnostic).
